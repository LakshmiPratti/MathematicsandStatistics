#! usr/bin/python3

file = open("ecoli_11kb.txt","r")
text = file.readline()
text = text.upper()
text = list(text)
length = len(text) 
count_A = 0
count_T = 0
count_C = 0
count_G = 0

#-----------------TO CALCULATE THE FREQUENCY OF A,T,G AND C---------------#

for i in range(length-1):
    if(text[i] == "A"):
        count_A = count_A + 1
    if(text[i] == "T"):
        count_T = count_T + 1
    if(text[i] == "C"):
        count_C= count_C + 1
    if(text[i] == "G"):
        count_G = count_G + 1

print("Frequency of A is: ",count_A)
print("Frequency of T is: " ,count_T)
print("Frequency of G is: ",count_G)
print("Frequency of C is: ",count_C)
print("\n")

#----------------------TO CALCULATE THE FREQUENCIES OF DINUCLEOTIDES-------------#

dinuc = {}
for i in range(length-1):
    k = (text[i],text[i+1])
    if k in dinuc:
        dinuc[k] += 1
    else:
        dinuc[k] = 1
print("The frequencies of dinucleotides are: \n")
print(dinuc)
print("\n")

#------------------------TO CALCULATE FREQUENCIES OF TRINUCLEOTIDES---------------#

trinuc ={}
for i in range(0,length-3,3):
    amino = ""
    for j in range(i,i+3):
        amino +=  text[j] #Storing 3 Characters
    if amino in trinuc:
        trinuc[amino] += 1
    else:
        trinuc[amino] = 1
print("The frequencies of trinucleotides are: \n")
print(trinuc)
          
