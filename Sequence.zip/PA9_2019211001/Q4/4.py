import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import re

def compute_purines(data, blocksize, purines_list):
    print("*********************************************************")
    print("Block size: ", blocksize)
    block_data = data[:blocksize]
    sum_purines = 0
    for base in purines_list:
        cnt = count_base(block_data, base)
        print("Count of ", base, ":", cnt)
        sum_purines += cnt
    prop_purines = sum_purines / blocksize 
    prop_purines = np.round(prop_purines,2)
    sd_purines = np.sqrt(prop_purines * (1-prop_purines)/ blocksize)
    sd_purines = np.round(sd_purines,5)
    
    print("Count of purines : ", sum_purines)
    print("Proportion of purines (mean) : ", prop_purines)
    print("standard deviation of proportion of purines :", sd_purines)
    print("1 standard deviation interval :", prop_purines - sd_purines, " & ", prop_purines + sd_purines)
    print("2 standard deviation interval :", prop_purines - (2*sd_purines), " & ", prop_purines + (2*sd_purines))
    print("3 standard deviation interval :", prop_purines - (3*sd_purines), " & ", prop_purines + (3*sd_purines))
    return prop_purines, sd_purines
        
                
def count_base(data, base):
    return len(re.findall(base,data))
    

purines_list = ['A','G']
confident_interval = 0.95

# read the file
f = open("ecoli_11kb.txt",'r')

data = f.read()
data = data.split('\n')[1]
data=data.upper()

# block size 100, 1000, 10000
mean_100, sd_100 = compute_purines(data, 100, purines_list)
mean_1000, sd_1000 = compute_purines(data, 1000, purines_list)
mean_10000, sd_10000 = compute_purines(data, 10000, purines_list)

# plot histogram 
df = pd.DataFrame({'blocksize': [100,1000,10000],
                   'mean':[mean_100, mean_1000, mean_10000],
                   'sd' : [sd_100, sd_1000, sd_10000]})
df.plot(kind='bar', x='blocksize', y='mean', figsize=(8,5), title='mean vs blocksize').get_figure().savefig('mean_plot.png')
df.plot(kind='bar', x='blocksize', y='sd', figsize=(8,5), title='sd vs blocksize').get_figure().savefig('sd_plot.png')





